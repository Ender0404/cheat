package com.example.qlhoa;

public class Loaihoa {

    String Mahoa;
    String Tenloaihoa;

    public Loaihoa(String mahoa, String tenloaihoa) {
        Mahoa = mahoa;
        Tenloaihoa = tenloaihoa;
    }

    public String getMahoa() {
        return Mahoa;
    }

    public void setMahoa(String mahoa) {
        Mahoa = mahoa;
    }

    public String getTenloaihoa() {
        return Tenloaihoa;
    }

    public void setTenloaihoa(String tenloaihoa) {
        Tenloaihoa = tenloaihoa;
    }
}
