import math

a=int(input("Nhap a : "))
b=int(input("Nhap b : "))

print(f"UCLN cua {a} va {b} la : {math.gcd(a,b)}")