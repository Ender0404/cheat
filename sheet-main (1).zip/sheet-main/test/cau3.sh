#!/bin/bash/

echo "---------------DATE---------------"
date +"Hom nay la ngay %d thang %m nam %Y"
date +"Bay gio la %H gio %M phut %S giay"
echo "Thank :))"
