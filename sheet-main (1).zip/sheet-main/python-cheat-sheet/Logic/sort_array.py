list = [5,8,7,5,3,9,1,2,3]



print(f"List acen: {sorted(list)}")
list.sort(reverse=True)
print(f"list dece: {list}")

