#! /bin/bash
echo "Enter your name : "
read ten
echo "Hello $ten, How are you today ?"
